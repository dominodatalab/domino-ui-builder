# Installing @domino/extensions from a tarball

This guide covers how to install `@domino/extensions` in your project using a `.tgz` tarball file provided by the Domino team.

- [Starting from scratch](#starting-from-scratch) — create a new Vite + React + TypeScript project first
- [Adding to an existing project](#adding-to-an-existing-project) — install into a project you already have

---

## Starting from scratch

Follow these steps if you are starting in an empty directory with no existing React project.

### Prerequisites

- Node.js >= 18.x
- yarn

### 1. Scaffold a Vite + React + TypeScript project

```bash
yarn create vite my-app --template react-ts
cd my-app
```

This creates a project with React 18, TypeScript, and Vite pre-configured.

### 2. Install the base project dependencies

```bash
yarn install
```

### 3. Install peer dependencies

`@domino/extensions` requires specific versions of the React router packages. Install them alongside the ones Vite already added:

```bash
yarn add react-router@5.3.4 react-router-dom@^5.3.0
```

> **Note:** Vite scaffolds React 18, which matches the version required by this package, so `react` and `react-dom` are already covered.

### 4. Install the package from the tarball

Place the `.tgz` file provided by the Domino team somewhere in your project (e.g. a `vendor/` folder) and run:

```bash
yarn add file:/path/to/domino-extensions-<version>.tgz
```

### 5. Update `tsconfig.json`

Open `tsconfig.json` and make sure these compiler options are present:

```json
{
  "compilerOptions": {
    "moduleResolution": "bundler",
    "esModuleInterop": true,
    "jsx": "react-jsx"
  }
}
```

Vite's default template already sets most of these — just verify `moduleResolution` is `"bundler"`.

### 6. Update `src/main.tsx`

Replace the contents of `src/main.tsx` with:

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { DominoThemeProviderDecorator } from '@domino/extensions';
import '@domino/extensions/style.css';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <DominoThemeProviderDecorator>
      <App />
    </DominoThemeProviderDecorator>
  </React.StrictMode>,
);
```

### 7. Start the dev server

```bash
yarn dev
```

Open the URL shown in the terminal. Your app is ready to use `@domino/extensions` components.

---

## Adding to an existing project

### Prerequisites

- Node.js >= 18.x
- yarn
- A React project

### Step 1: Obtain the tarball

The Domino team will provide you with a file named:

```
domino-extensions-<version>.tgz
```

Place it somewhere accessible from your project (e.g. a `vendor/` folder at the root).

### Step 2: Install the package

```bash
yarn add file:/path/to/domino-extensions-<version>.tgz
```

### Step 3: Install peer dependencies

The package requires the following peer dependencies to be installed in your project:

```bash
yarn add react@18.2.0 react-dom@18.2.0 react-router@5.3.4 react-router-dom@^5.3.0
```

### Step 4: Import styles

Add the CSS import once at the top level of your application (e.g. `index.tsx` or `App.tsx`):

```tsx
import '@domino/extensions/style.css';
```

### Step 5: Wrap your app

Wrap your application with `DominoThemeProviderDecorator` to enable theming:

```tsx
import { DominoThemeProviderDecorator } from '@domino/extensions';
import '@domino/extensions/style.css';

function App() {
  return (
    <DominoThemeProviderDecorator>
      <YourApp />
    </DominoThemeProviderDecorator>
  );
}
```

## Avoiding API requests with a custom store hook

By default, `DominoThemeProviderDecorator` uses the internal `useStoreExtension` hook to fetch the current user's principal and white-label settings from the Domino backend. In standalone or third-party applications that don't have access to that backend, this will trigger failing network requests.

To prevent this, pass a custom `useStoreHook` prop that returns static values instead:

```tsx
import { DominoThemeProviderDecorator } from '@domino/extensions';
import '@domino/extensions/style.css';

// A no-op hook — skips all API calls and uses the theme defaults
function useStaticStore() {
  return {
    formattedPrincipal: undefined,
    whiteLabelSettings: undefined,
  };
}

function App() {
  return (
    <DominoThemeProviderDecorator useStoreHook={useStaticStore}>
      <YourApp />
    </DominoThemeProviderDecorator>
  );
}
```

If you want the theme to reflect a specific user or branding, you can provide static values:

```tsx
import { DominoThemeProviderDecorator } from '@domino/extensions';
import '@domino/extensions/style.css';

function useStaticStore() {
  return {
    formattedPrincipal: {
      _loaded: true,
      dominoHome: true,
      // add any other FormattedPrincipal flags your app needs
    },
    whiteLabelSettings: {
      logoUrl: 'https://your-company.com/logo.png',
      primaryColor: '#0057D9',
    },
  };
}

function App() {
  return (
    <DominoThemeProviderDecorator useStoreHook={useStaticStore}>
      <YourApp />
    </DominoThemeProviderDecorator>
  );
}
```

> **When to use this:** Any time your app runs outside the Domino platform and does not have access to the Domino backend. Passing `useStoreHook` prevents 401/network errors on startup and makes the theme work in fully offline or standalone environments.

---

## TypeScript configuration

Add the following options to your `tsconfig.json`:

```json
{
  "compilerOptions": {
    "moduleResolution": "bundler",
    "esModuleInterop": true,
    "jsx": "react-jsx"
  }
}
```

## Troubleshooting

**Components look unstyled**
Make sure you imported the CSS file as shown in Step 4.

**`./assets/style.css` is not exported from package `@domino/extensions`**

This error appears in Vite when the installed tarball was built with an older version of the package that placed the CSS file at `dist/assets/style.css` instead of `dist/style.css`. The `package.json` exports map expects the CSS at the root of `dist/`.

Obtain and reinstall a tarball built from version `1.0.0-beta.31` or later, then clear your Vite cache:

```bash
rm -rf node_modules/.vite
yarn dev
```

**`Could not resolve './node_modules/@domino/api/dist/...'`**

This error means the tarball was built before `1.0.0-beta.32`. With `preserveModules` enabled, Rollup was preserving the physical `node_modules/` path of bundled packages, creating broken relative imports after installation. This is fixed in `1.0.0-beta.32`+. Reinstall from a newer tarball.

**Module not found**
Ensure all peer dependencies are installed (Step 3).

**TypeScript errors after install**
Clear your package cache and reinstall:

```bash
rm -rf node_modules yarn.lock
yarn install
```
