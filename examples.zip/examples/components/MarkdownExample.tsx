import { Card, Markdown, Typography } from "@domino/extensions";
import type { ReactNode } from "react";

interface MarkdownExampleProps {
  title: string;
  description?: ReactNode;
  source: string;
  supportMentions?: boolean;
}

export function MarkdownExample({
  title,
  description,
  source,
  supportMentions,
}: MarkdownExampleProps) {
  return (
    <Card title={title} helpMessage={description}>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 16,
          alignItems: "stretch",
        }}
      >
        <div>
          <Typography.Text type="BodySmallStrong">Source</Typography.Text>
          <pre
            style={{
              background: "#f6f8fa",
              border: "1px solid #e1e4e8",
              borderRadius: 6,
              padding: 12,
              margin: "8px 0 0",
              overflow: "auto",
              fontFamily:
                "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
              fontSize: 12,
              lineHeight: 1.5,
              whiteSpace: "pre",
              maxHeight: 360,
            }}
          >
            {source}
          </pre>
        </div>
        <div>
          <Typography.Text type="BodySmallStrong">Rendered</Typography.Text>
          <div
            style={{
              background: "#fff",
              border: "1px solid #e1e4e8",
              borderRadius: 6,
              padding: 16,
              marginTop: 8,
              maxHeight: 360,
              overflow: "auto",
            }}
          >
            <Markdown supportMentions={supportMentions}>{source}</Markdown>
          </div>
        </div>
      </div>
    </Card>
  );
}
