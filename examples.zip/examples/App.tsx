import { useState } from "react";
import { Redirect, Route, Switch, useHistory, useLocation } from "react-router-dom";
import { IconResolver, SideBar } from "@domino/extensions";
import { BasicsPage } from "./pages/BasicsPage";
import { GfmPage } from "./pages/GfmPage";
import { CodePage } from "./pages/CodePage";
import { MathPage } from "./pages/MathPage";
import { MentionsPage } from "./pages/MentionsPage";
import { PlaygroundPage } from "./pages/PlaygroundPage";

const navItems = [
  {
    key: "/basics",
    label: "Basics",
    icon: <IconResolver collection="light" icon="BookOpen" aria-label="basics" />,
  },
  {
    key: "/gfm",
    label: "GFM extensions",
    icon: <IconResolver collection="light" icon="Table" aria-label="gfm" />,
  },
  {
    key: "/code",
    label: "Code blocks",
    icon: <IconResolver collection="light" icon="Code" aria-label="code" />,
  },
  {
    key: "/math",
    label: "Math (LaTeX)",
    icon: <IconResolver collection="light" icon="Calculator" aria-label="math" />,
  },
  {
    key: "/mentions",
    label: "Mentions",
    icon: <IconResolver collection="light" icon="At" aria-label="mentions" />,
  },
  {
    key: "/playground",
    label: "Live playground",
    icon: <IconResolver collection="light" icon="PenToSquare" aria-label="playground" />,
  },
];

export default function App() {
  const history = useHistory();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      <SideBar
        items={navItems}
        section={<span>Demo</span>}
        name={<span>Markdown component</span>}
        tag={<span>@domino/extensions</span>}
        selectedKeys={[location.pathname]}
        collapsed={collapsed}
        handleCollapse={() => setCollapsed((c) => !c)}
        onClick={(info: { key: string }) => history.push(info.key)}
      />
      <div
        style={{
          flex: 1,
          overflow: "auto",
          padding: 24,
          background: "#fafbfc",
        }}
      >
        <Switch>
          <Route path="/basics" component={BasicsPage} />
          <Route path="/gfm" component={GfmPage} />
          <Route path="/code" component={CodePage} />
          <Route path="/math" component={MathPage} />
          <Route path="/mentions" component={MentionsPage} />
          <Route path="/playground" component={PlaygroundPage} />
          <Redirect to="/basics" />
        </Switch>
      </div>
    </div>
  );
}
