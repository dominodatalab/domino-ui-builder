import { Space } from "@domino/extensions";
import { MarkdownExample } from "../components/MarkdownExample";
import { PageHeader } from "./PageHeader";

const INLINE = `Use backticks for inline code: \`const x = 42;\`.

Useful inside prose: invoke \`projectClient.fetchAll()\` to load every project, or set
\`DOMINO_API_KEY\` in your environment.
`;

const PYTHON = `\`\`\`python
from domino import Domino

def main() -> None:
    client = Domino("acme/quick-start")
    for run in client.runs_list()["data"]:
        print(f"{run['number']:>4}  {run['status']:<10}  {run['startingUser']}")

if __name__ == "__main__":
    main()
\`\`\`
`;

const TYPESCRIPT = `\`\`\`tsx
import { Markdown } from '@domino/extensions';

interface DescriptionProps {
  body: string;
}

export function Description({ body }: DescriptionProps) {
  if (!body) return null;
  return <Markdown supportMentions>{body}</Markdown>;
}
\`\`\`
`;

const BASH = `\`\`\`bash
# Install the extensions library from a local tarball
npm install file:./domino-extensions-v1.0.1.tgz
npm install react-router@5.3.4 react-router-dom@^5.3.0

# Start the dev server
npm run dev
\`\`\`
`;

const JSON_SAMPLE = `\`\`\`json
{
  "name": "fraud-detection",
  "hardwareTier": "small-k8s",
  "environment": {
    "id": "env-7c4f1",
    "revision": 12
  },
  "schedule": {
    "cron": "0 */6 * * *",
    "timezone": "UTC"
  }
}
\`\`\`
`;

const DIFF = `\`\`\`diff
- import { Markdown } from 'react-markdown';
+ import { Markdown } from '@domino/extensions';

  function Description({ body }) {
-   return <Markdown source={body} />;
+   return <Markdown>{body}</Markdown>;
  }
\`\`\`
`;

const SQL = `\`\`\`sql
SELECT
  project_id,
  COUNT(*) AS run_count,
  AVG(duration_seconds) AS avg_duration
FROM runs
WHERE status = 'Succeeded'
  AND started_at >= NOW() - INTERVAL '7 days'
GROUP BY project_id
ORDER BY run_count DESC
LIMIT 10;
\`\`\`
`;

export function CodePage() {
  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="Code blocks"
        subtitle="Fenced code blocks with language hints — styled by the bundled github-markdown CSS."
      />
      <MarkdownExample
        title="Inline code"
        description="Single backticks wrap technical terms inside prose."
        source={INLINE}
      />
      <MarkdownExample
        title="Python"
        description="Fenced block with the python language hint."
        source={PYTHON}
      />
      <MarkdownExample
        title="TypeScript / TSX"
        description="JSX renders cleanly inside a tsx fence."
        source={TYPESCRIPT}
      />
      <MarkdownExample
        title="Shell"
        description="Common pattern for install instructions."
        source={BASH}
      />
      <MarkdownExample
        title="JSON"
        description="Config snippets in run descriptions and docs."
        source={JSON_SAMPLE}
      />
      <MarkdownExample
        title="Diff"
        description="Show before/after edits in changelogs."
        source={DIFF}
      />
      <MarkdownExample
        title="SQL"
        description="Query snippets shared between teammates."
        source={SQL}
      />
    </Space>
  );
}
