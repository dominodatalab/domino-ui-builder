import { Typography } from "@domino/extensions";
import type { ReactNode } from "react";

interface PageHeaderProps {
  title: string;
  subtitle: ReactNode;
}

export function PageHeader({ title, subtitle }: PageHeaderProps) {
  return (
    <div style={{ marginBottom: 24 }}>
      <Typography.H1>{title}</Typography.H1>
      <Typography.Text type="BodyDefault">{subtitle}</Typography.Text>
    </div>
  );
}
