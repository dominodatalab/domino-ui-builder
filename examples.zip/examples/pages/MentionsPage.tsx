import { Callout, Space } from "@domino/extensions";
import { MarkdownExample } from "../components/MarkdownExample";
import { PageHeader } from "./PageHeader";

const COMMENT = `@alice Thanks for the review! I've addressed the feedback from @bob and rebased on main.

Pinging @carol so she's aware before the demo tomorrow.
`;

const ACTIVITY = `**Activity feed**

- @dave started run #4824 in *fraud-detection*
- @erin published a new model version (v3.2.1)
- @frank approved a PR opened by @grace
- @hank added a comment: _"Looks great, ship it!"_
`;

const WITHOUT_MENTIONS = `Without the \`supportMentions\` prop, the same text @alice and @bob renders as plain text.

This is the right default for content where \`@\` is not a user reference (release notes, API examples, etc.).
`;

export function MentionsPage() {
  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="Mentions"
        subtitle="Set supportMentions to turn @username into a link to that user's profile."
      />
      <Callout
        type="info"
        message={
          <span>
            With <code>supportMentions</code> enabled, tokens that look like{" "}
            <code>@username</code> are rewritten to{" "}
            <code>[@username](/u/username)</code> before rendering — best for
            comments, activity feeds, and collaborative threads.
          </span>
        }
      />
      <MarkdownExample
        title="Comment thread"
        description="Typical use: a comment with multiple @-mentions."
        source={COMMENT}
        supportMentions
      />
      <MarkdownExample
        title="Activity feed"
        description="Mixed with lists and emphasis."
        source={ACTIVITY}
        supportMentions
      />
      <MarkdownExample
        title="Default behaviour (mentions disabled)"
        description="Same input without supportMentions — @ tokens stay as text."
        source={WITHOUT_MENTIONS}
      />
    </Space>
  );
}
