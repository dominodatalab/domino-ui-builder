import { useState } from "react";
import type { ChangeEvent } from "react";
import {
  Button,
  Card,
  Markdown,
  Radio,
  Space,
  TextArea,
  Toggle,
  Typography,
} from "@domino/extensions";
import { PageHeader } from "./PageHeader";

type Preset = "Welcome" | "GFM" | "Math" | "Mentions";

const PRESETS: Record<Preset, string> = {
  Welcome: `# Welcome to the playground

Edit the markdown on the **left** and watch it render on the **right** in real time.

Try:

- Switching the *preset* using the buttons above
- Toggling **@mentions** support
- Pasting a snippet from another page in this demo

> Tip: the preview is the same \`<Markdown />\` component used in every other page.
`,
  GFM: `## Sprint status

| Engineer | Tickets | Status        |
| -------- | ------: | ------------- |
| Alice    |       7 | On track      |
| Bob      |       4 | ~~Blocked~~   |
| Carol    |       9 | Ahead         |

### To-do

- [x] Spec review
- [x] Backend endpoint
- [ ] Frontend wiring
- [ ] QA pass
`,
  Math: `### Energy

Mass-energy: $E = mc^2$.

The integral of the Gaussian:

$$
\\int_{-\\infty}^{\\infty} e^{-x^2}\\, dx = \\sqrt{\\pi}
$$
`,
  Mentions: `@alice can you take a look at the metrics regression?

@bob and @carol — meeting at 3pm to discuss the rollback plan.

Re-pinging @dave on the env upgrade — blocking on this.
`,
};

export function PlaygroundPage() {
  const [preset, setPreset] = useState<Preset>("Welcome");
  const [source, setSource] = useState<string>(PRESETS.Welcome);
  const [mentions, setMentions] = useState<boolean>(false);

  const handlePreset = (next: Preset) => {
    setPreset(next);
    setSource(PRESETS[next]);
  };

  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="Live playground"
        subtitle="A two-pane editor — type markdown on the left, see it rendered on the right."
      />

      <Card
        title="Controls"
        extra={
          <Button type="tertiary" onClick={() => setSource(PRESETS[preset])}>
            Reset to preset
          </Button>
        }
      >
        <Space direction="horizontal" gap="spacingLarge">
          <div>
            <Typography.Text type="BodySmallStrong">Preset</Typography.Text>
            <div style={{ marginTop: 6 }}>
              <Radio.Group
                optionType="button"
                value={preset}
                onChange={(e: { target: { value: unknown } }) =>
                  handlePreset(e.target.value as Preset)
                }
                options={[
                  { label: "Welcome", value: "Welcome" },
                  { label: "GFM", value: "GFM" },
                  { label: "Math", value: "Math" },
                  { label: "Mentions", value: "Mentions" },
                ]}
              />
            </div>
          </div>
          <div>
            <Typography.Text type="BodySmallStrong">Options</Typography.Text>
            <div style={{ marginTop: 6 }}>
              <Toggle
                checked={mentions}
                onChange={(checked: boolean) => setMentions(checked)}
                label="supportMentions"
              />
            </div>
          </div>
        </Space>
      </Card>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 16,
          alignItems: "stretch",
        }}
      >
        <Card title="Markdown source">
          <TextArea
            value={source}
            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setSource(e.target.value)}
            autoSize={{ minRows: 18, maxRows: 30 }}
            style={{
              fontFamily:
                "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
              fontSize: 13,
            }}
            aria-label="markdown source"
          />
        </Card>
        <Card title="Rendered preview">
          <div
            style={{
              minHeight: 360,
              background: "#fff",
              border: "1px solid #e1e4e8",
              borderRadius: 6,
              padding: 16,
            }}
          >
            <Markdown supportMentions={mentions}>{source}</Markdown>
          </div>
        </Card>
      </div>
    </Space>
  );
}
