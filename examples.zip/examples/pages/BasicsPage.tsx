import { Space } from "@domino/extensions";
import { MarkdownExample } from "../components/MarkdownExample";
import { PageHeader } from "./PageHeader";

const HEADINGS = `# Heading 1 — page title
## Heading 2 — section
### Heading 3 — subsection
#### Heading 4
##### Heading 5
###### Heading 6
`;

const EMPHASIS = `Markdown supports **bold**, *italic*, ***bold italic***, and ~~strikethrough~~ inline text.

Inline \`code spans\` are great for variable names like \`projectId\` or short paths.

You can mix them: a **bold _nested italic_** word, or a *call to \`fetchProject()\`*.
`;

const LINKS = `Use [inline links](https://www.dominodatalab.com) for navigation.

Reference-style links work too: see [the Domino docs][docs] for more.

Raw URLs auto-link: https://github.com/dominodatalab

[docs]: https://docs.dominodatalab.com
`;

const LISTS = `**Unordered list**

- Datasets
- Environments
  - Compute environments
  - Hardware tiers
- Workspaces

**Ordered list**

1. Create a project
2. Configure compute
3. Launch a workspace
   1. Open a Jupyter notebook
   2. Run your first cell
`;

const BLOCKQUOTES = `> "Reproducibility is the heart of trustworthy data science."
>
> — Project README

Multi-paragraph quotes are supported:

> First paragraph of the quote.
>
> Second paragraph — useful for citing longer passages.
`;

const HORIZONTAL = `Above the rule.

---

Below the rule. Use \`---\` to separate sections of long-form markdown content.
`;

export function BasicsPage() {
  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="Basics"
        subtitle="The foundational markdown syntax — headings, emphasis, links, lists, blockquotes, and horizontal rules."
      />
      <MarkdownExample
        title="Headings"
        description="Six levels of headings, sized by Domino's markdown styles."
        source={HEADINGS}
      />
      <MarkdownExample
        title="Emphasis & inline code"
        description="Bold, italic, strikethrough, and inline code spans."
        source={EMPHASIS}
      />
      <MarkdownExample
        title="Links"
        description="Inline, reference-style, and auto-linked URLs."
        source={LINKS}
      />
      <MarkdownExample
        title="Lists"
        description="Ordered and unordered lists with nesting."
        source={LISTS}
      />
      <MarkdownExample
        title="Blockquotes"
        description="Single- and multi-paragraph quotes."
        source={BLOCKQUOTES}
      />
      <MarkdownExample
        title="Horizontal rules"
        description="Use --- to separate long sections."
        source={HORIZONTAL}
      />
    </Space>
  );
}
