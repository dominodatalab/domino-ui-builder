import { Space } from "@domino/extensions";
import { MarkdownExample } from "../components/MarkdownExample";
import { PageHeader } from "./PageHeader";

const TABLES = `| Run ID | Status     | Duration | Owner          |
| ------ | ---------- | -------: | -------------- |
| 4821   | Succeeded  |   2m 14s | alice@acme.io  |
| 4822   | Failed     |   0m 47s | bob@acme.io    |
| 4823   | Running    |        — | carol@acme.io  |
| 4824   | Queued     |        — | dave@acme.io   |

Column alignment is controlled by the dashes in the separator row:
\`---\` (left), \`:---:\` (center), \`---:\` (right).
`;

const TASK_LISTS = `**Sprint backlog**

- [x] Wire up authentication
- [x] Add project list endpoint
- [ ] Build the run detail page
- [ ] Connect to the metrics service
  - [x] Define the schema
  - [ ] Implement the loader
  - [ ] Write integration tests
`;

const STRIKETHROUGH = `Mark deprecated items by wrapping them in two tildes:

- ~~Old API endpoint: \`/v1/runs/list\`~~
- New API endpoint: \`/v2/runs\`

Useful for changelogs and diffs in documentation.
`;

const AUTOLINK = `URLs and email addresses are linkified automatically with GFM.

- Visit https://docs.dominodatalab.com for tutorials
- Email support@dominodatalab.com for help
- Or open an issue at https://github.com/dominodatalab/example/issues
`;

const FOOTNOTES = `Markdown supports footnotes for academic-style citations.[^1]

You can reference the same footnote multiple times[^1], or define longer notes[^longnote] inline.

[^1]: This is a short footnote.
[^longnote]: A longer footnote can span multiple lines and contain its own formatting like **bold** or \`code\`.
`;

export function GfmPage() {
  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="GitHub Flavored Markdown"
        subtitle="Extensions beyond CommonMark — tables, task lists, strikethrough, autolinks, and footnotes."
      />
      <MarkdownExample
        title="Tables"
        description="Pipe-delimited tables with per-column alignment."
        source={TABLES}
      />
      <MarkdownExample
        title="Task lists"
        description="Interactive-looking checkboxes for to-do and progress tracking."
        source={TASK_LISTS}
      />
      <MarkdownExample
        title="Strikethrough"
        description="Two tildes wrap deleted or deprecated content."
        source={STRIKETHROUGH}
      />
      <MarkdownExample
        title="Autolinks"
        description="URLs and emails are turned into links automatically."
        source={AUTOLINK}
      />
      <MarkdownExample
        title="Footnotes"
        description="Reference-style footnotes for citations and asides."
        source={FOOTNOTES}
      />
    </Space>
  );
}
