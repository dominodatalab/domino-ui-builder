import { Space } from "@domino/extensions";
import { MarkdownExample } from "../components/MarkdownExample";
import { PageHeader } from "./PageHeader";

const INLINE_MATH = `Einstein's mass-energy equivalence is $E = mc^2$.

The standard normal PDF is $\\phi(x) = \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}$, which integrates to 1 over the real line.

Greek letters and operators work inline too: $\\alpha + \\beta = \\gamma$, $\\sum_{i=1}^{n} x_i$, $\\lim_{x \\to 0} \\frac{\\sin x}{x} = 1$.
`;

const DISPLAY_MATH = `**Gaussian integral**

$$
\\int_{-\\infty}^{\\infty} e^{-x^2}\\, dx = \\sqrt{\\pi}
$$

**Bayes' theorem**

$$
P(A \\mid B) = \\frac{P(B \\mid A)\\, P(A)}{P(B)}
$$

**Fourier transform**

$$
\\hat{f}(\\xi) = \\int_{-\\infty}^{\\infty} f(x)\\, e^{-2\\pi i x \\xi}\\, dx
$$
`;

const MATRICES = `**A 3×3 matrix**

$$
A = \\begin{pmatrix}
a_{11} & a_{12} & a_{13} \\\\
a_{21} & a_{22} & a_{23} \\\\
a_{31} & a_{32} & a_{33}
\\end{pmatrix}
$$

**A determinant**

$$
\\det\\begin{vmatrix}
1 & 2 \\\\
3 & 4
\\end{vmatrix} = 1 \\cdot 4 - 2 \\cdot 3 = -2
$$
`;

const ML = `**Linear regression**

$$
\\hat{y} = X\\beta + \\varepsilon, \\quad \\hat{\\beta} = (X^\\top X)^{-1} X^\\top y
$$

**Cross-entropy loss**

$$
\\mathcal{L} = -\\frac{1}{N} \\sum_{i=1}^{N} \\sum_{c=1}^{C} y_{i,c} \\log \\hat{y}_{i,c}
$$

**Softmax**

$$
\\sigma(z)_i = \\frac{e^{z_i}}{\\sum_{j=1}^{K} e^{z_j}}
$$
`;

export function MathPage() {
  return (
    <Space direction="vertical" style={{ width: "100%" }} gap="spacingLarge">
      <PageHeader
        title="Math (LaTeX)"
        subtitle="Rendered by remark-math + rehype-mathjax — inline with $...$ and display with $$...$$."
      />
      <MarkdownExample
        title="Inline math"
        description="Math expressions mixed with prose using $...$."
        source={INLINE_MATH}
      />
      <MarkdownExample
        title="Display math"
        description="Centered block equations using $$...$$."
        source={DISPLAY_MATH}
      />
      <MarkdownExample
        title="Matrices & determinants"
        description="pmatrix / vmatrix environments work as expected."
        source={MATRICES}
      />
      <MarkdownExample
        title="Machine learning"
        description="Common loss functions and model definitions."
        source={ML}
      />
    </Space>
  );
}
